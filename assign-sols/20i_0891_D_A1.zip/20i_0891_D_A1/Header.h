// Muhammad Munaf UL Hassan 20i-0891
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

double supportThreshold;
int noOfTransactions;
bool SetOneDone = 0;

int checkCharSize(char* str)
{
    int i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return i;
}

void removePunctuationMarks(char* str)
{
    int s = checkCharSize(str);

    for (int i = 0; i < s; i++)
    {
        if (str[i] >= 33 && str[i] <= 47 || str[i] >= 58 && str[i] <= 64 || str[i] == ' ' || str[i] == '|') // special chars
        {
            if (str[i] == ',')
            {
                continue;
            }

            for (int j = i; j < s; j++)
            {
                char temp = str[j + 1];
                str[j] = temp;
            }
        }
        if (str[i] >= 48 && str[i] <= 57) // digits
        {
            for (int j = i; j < s; j++)
            {
                char temp = str[j + 1];
                str[j] = temp;
            }
        }
    }

    for (int i = 0; i < s; i++)
    {
        if (str[i] == ',')
        {
            str[i] = ' ';
        }
    }
}

void convertUpperToLowerCase(char* str)
{
    int s = checkCharSize(str);

    for (int i = 0; i < s; i++)
    {
        if (str[i] >= 65 && str[i] <= 90)
        {
            str[i] = str[i] + 32;
        }
    }
}

char* charConcatinate(char* arr, char* add) // connects two char arrays together like string concatination
{
    int s1 = checkCharSize(arr);
    int s2 = checkCharSize(add);

    int totalSize = s1 + s2 + 1;
    char* temp = new char[totalSize];

    for (int i = 0; i < totalSize; i++)
    {
        if (i < s1)
            temp[i] = arr[i];
        else if (s1 == i)
            temp[i] = ',';
        else if (i > s1)
            temp[i] = add[i - s1 - 1];

    }

    return temp;
}

int charArraySum(char* arr)
{
    int s = checkCharSize(arr);
    int sum = 0;
    for (int i = 0; i < s; i++)
    {
        sum += int(arr[i]);
    }
    return sum;
}

class Item
{

public:

    Item* next;
    char* data;
    int freq;
    Item()
    {
        next = NULL;
        data = NULL;
        freq = 1;
    }

};


class TransactionLL;

TransactionLL* head = NULL;

class TransactionLL
{

public:
    TransactionLL* next;
    Item* items;

    TransactionLL()
    {
        items = NULL;
        next = NULL;
    }

    void insertTrasaction(char* str)
    {
        if (head == NULL) // incase there are no previous entries
        {
            head = new TransactionLL;
            TransactionLL* tempTrans = head;
            tempTrans->next = NULL;

            char* tempStr = new char[20];

            int i = 0, j = 0;
            while (1)
            {
                if (str[i] == ',' || str[i] == '\0')
                {

                    Item* tempItem = new Item;

                    tempStr[j] = 0;

                    tempItem->data = tempStr;

                    if (tempTrans->items == NULL) // if first item is being added
                    {
                        tempTrans->items = tempItem;
                        tempItem->next = NULL;
                    }
                    else
                    {
                        Item* tempp = tempTrans->items;
                        while (tempp->next != NULL)
                            tempp = tempp->next;
                        tempp->next = tempItem;
                    }

                    j = 0;
                    if (str[i] == '\0')
                        break;
                    else
                    {
                        tempStr = new char[20];
                        i++;
                    }
                }
                tempStr[j] = str[i];

                j++;
                i++;
            }
        }
        else
        {
            TransactionLL* tempCurrent = head;
            while (1)
            {
                if (tempCurrent->next == NULL)
                {
                    TransactionLL* tempTrans = new TransactionLL;
                    tempCurrent->next = tempTrans;
                    tempTrans->next = NULL;
                    char* tempStr = new char[20];

                    int i = 0, j = 0;
                    while (1)
                    {
                        if (str[i] == ',' || str[i] == '\0')
                        {

                            Item* tempItem = new Item;

                            tempStr[j] = 0;

                            tempItem->data = tempStr;

                            if (tempTrans->items == NULL) // if first item is being added
                            {
                                tempTrans->items = tempItem;
                                tempItem->next = NULL;
                            }
                            else
                            {
                                Item* tempp = tempTrans->items;
                                while (tempp->next != NULL)
                                    tempp = tempp->next;
                                tempp->next = tempItem;
                            }

                            j = 0;
                            if (str[i] == '\0')
                                break;
                            else
                            {
                                tempStr = new char[20];
                                i++;
                            }
                        }
                        tempStr[j] = str[i];

                        j++;
                        i++;
                    }
                    break;
                }

                tempCurrent = tempCurrent->next;
            }
        }
    }

    void printAll()
    {
        TransactionLL* tempTrans = head;
        cout << endl;
        while (1)
        {
            if (tempTrans == NULL)
                break;

            Item* tempItems;
            tempItems = tempTrans->items;

            while (1)
            {
                //cout << tempItems->data << " " << tempItems->freq << " ,"; // not showing any output here even tho the address of this is same as the one used before to store data
                cout << tempItems->data << " ,";
                if (tempItems->next == NULL)
                    break;

                tempItems = tempItems->next;
            }

            tempTrans = tempTrans->next;
            cout << endl;
        }
    }

    void formatData(int i)
    {
        TransactionLL* tempTrans = head;

        if (i == 0)
        {
            while (1)
            {
                if (tempTrans == NULL)
                    break;

                Item* tempItems;
                tempItems = tempTrans->items;

                while (1)
                {
                    removePunctuationMarks(tempItems->data);

                    if (tempItems->next == NULL)
                        break;

                    tempItems = tempItems->next;
                }

                tempTrans = tempTrans->next;
            }
            //writingTransactionLLToFile("AfterPunctuation.txt");
        }
        else
        {
            tempTrans = head;
            while (1)
            {
                if (tempTrans == NULL)
                    break;

                Item* tempItems;
                tempItems = tempTrans->items;

                while (1)
                {
                    convertUpperToLowerCase(tempItems->data);
                    if (tempItems->next == NULL)
                        break;

                    tempItems = tempItems->next;
                }

                tempTrans = tempTrans->next;
            }
            //writingTransactionLLToFile("AfterPunctuationUpperToLower.txt");
        }

    }

    void checkFrequency()
    {
        TransactionLL* tempTrans = head;

        while (1) // for iterating through each transaction
        {
            if (tempTrans == NULL)
                break;

            Item* tempItems;
            tempItems = tempTrans->items;

            while (1) // for checking each item
            {
                // right now we are at the first item and we need to go through each item after that and see how many duplicates it has and delete each of those duplicates
                countItem(tempItems);

                if (tempItems->next == NULL)
                    break;

                tempItems = tempItems->next;
            }
            tempTrans = tempTrans->next;
        }

    }

    void countItem(Item* checkItem)
    {
        TransactionLL* tempTrans = head;
        //Item* prevItem = NULL;

        //bool itemDeleted = 0;

        while (1)
        {
            if (tempTrans == NULL)
                break;

            Item* tempItems;
            tempItems = tempTrans->items;


            while (1)
            {
                //cout << "Previous Item: " << prevItem << " Data: " << prevItem->data << endl;
                //cout << "Temp Item: " << tempItems <<" Data: " << tempItems->data << endl;

                if (*(checkItem->data) == *(tempItems->data) && checkItem != tempItems) // the data inside them has to be same but the address to be different
                {
                    checkItem->freq = checkItem->freq + 1; // incrementing frequency of current item
                    //cout << "Working 1\n";
                    //tempItems = deleteItem(tempItems, prevItem);
                    //cout << "Working 2\n";
                    //itemDeleted = 1;
                    break;
                }

                if (tempItems->next == NULL)
                    break;

                //prevItem = tempItems;
                //if(!itemDeleted)
                tempItems = tempItems->next;
            }
            tempTrans = tempTrans->next;

        }
    }

    void deleteItem(char* deleteItem)
    {
        TransactionLL* tempTrans = head;
        Item* tempItems;
        Item* prev = NULL;
        int i = 0;
        while (1)
        {
            if (tempTrans == NULL)
                break;

            tempItems = tempTrans->items;

            while (1)
            {
                if (tempItems == NULL)
                    break;

                //cout << tempItems->data << " == " << deleteItem << endl;
                if (tempItems->data[0] == deleteItem[0])
                {
                    //cout << prev->data << " -> " << tempItems->data << endl;
                    if (prev == NULL) // the very first item is never a duplicate
                    {
                        //do nothing in this case
                        //cout << "1\n";
                    }
                    else if (tempItems->next == NULL && tempTrans->next != NULL) // last item of transaction but not the very last of all
                    {
                        //printAll();
                        //cout << "2\n";
                        //tempTrans->items = tempItems->next;
                        //cout << "item is: " << temp
                        delete tempItems;
                        prev->next = NULL;
                        tempItems = prev;
                    }
                    else if (tempItems->next != NULL) // deleting middle item
                    {
                        //cout << "3\n";
                        prev->next = tempItems->next;
                        delete tempItems;
                        tempItems = prev;
                    }
                    else if (tempTrans->next == NULL) // deleting the very last elemnt
                    {
                        //cout << "4\n";
                        prev->next = NULL;
                        delete tempItems;
                        tempItems = prev;
                    }
                    else if (tempItems->next == NULL && tempTrans->next == NULL) // last item of all the data
                    {
                        //cout << "5\n";
                        prev->next = NULL;
                        delete tempItems;
                        tempItems = prev;
                    }
                }
                if (tempItems == NULL)
                    break;

                prev = tempItems;
                tempItems = tempItems->next;
            }
            if (i == noOfTransactions - 1)
                break;
            if (tempTrans != NULL)
            {
                //cout << "Transaction Address: " << tempTrans << endl;
                //cin.ignore(1);
                tempTrans = tempTrans->next;
            }

        }
        //cout << "going out of loop\n";
    }

};

void printItems(Item* temp) // not really useful can remove this
{
    //Item* temp;
    //temp = head->items;
    while (1)
    {
        cout << temp->data << endl; // not showing any output here even tho the address of this is same as the one used before to store data
        if (temp->next == NULL)
            break;

        temp = temp->next;
    }
}

void removeCharDuplicates(char** arr, int& s)
{
    for (int i = 0; i < s; i++)
    {
        for (int j = i; j < s; j++)
        {
            if (arr[i][0] == arr[j][0] && i != j && arr[i][1] == arr[j][1])
            {
                for (int k = j; k < s; k++)
                {
                    arr[k] = arr[k + 1];
                }
                s--;
            }
        }
    }
    s--;
}

void sortList(char** tempArray, int i)
{
    for (int j = 0; j < i; j++)
        cout << tempArray[j] << " ";

    cout << endl;

    TransactionLL* tempTrans = head;
    Item* prevItems = NULL;
    int k = 0;
    int tempvar = 0;
    Item* tempItems;

    while (1)
    {
        if (tempTrans == NULL)
            break;


        tempItems = tempTrans->items;

        while (1)
        {
            if (k == i)
                break;

            //cout << tempItems->data << " == " << tempArray[k] << "|\n";
            if (tempItems->data[0] == tempArray[k][0] && tempItems->data[1] == tempArray[k][1]) // in temp array, on each index, an element is stored which comes inside the freq range
            {
                //cout << "Show Data: " << tempItems->data << " " << tempItems->freq << endl;
                if (prevItems == NULL)
                {
                    prevItems = tempItems;
                    tempvar = k;
                }
                else
                {
                    cout << "Show Item: " << tempItems->data << " > " << prevItems->data << endl;
                    cout << "Show FREQ: " << tempItems->freq << " > " << prevItems->freq << endl;
                    if (tempItems->freq < prevItems->freq)
                    {
                        // then swap data
                        char* temp = tempArray[tempvar];
                        tempArray[tempvar] = tempArray[k];
                        tempArray[k] = temp;

                        cout << tempArray[tempvar] << " swapped " << tempArray[k] << endl;
                        cout << endl;
                        for (int j = 0; j < i; j++)
                            cout << tempArray[j] << " ";

                        cout << endl << endl;


                        tempvar++;
                    }
                }

                k++;
                //tempvar = k;
            }

            if (tempItems->next == NULL)
                break;

            prevItems = tempItems;
            tempItems = tempItems->next;
        }

        tempTrans = tempTrans->next;
    }

    for (int j = 0; j < i; j++)
        cout << tempArray[j] << " ";
}

char* tempArray[25]; // stores the list of unique items
int tempArraySize; // stores no. of unique items

void printAll(TransactionLL*);

void sortSetOne(TransactionLL* headPtr)
{
    TransactionLL* tempTrans = headPtr;

    Item* prevItem = NULL;
    char* tempData;
    int tempFreq;
    Item* tempItem = tempTrans->items;

    while (1)
    {
        if (prevItem == NULL)
        {
            prevItem = tempItem;
            tempItem = tempItem->next;
            continue;
        }

        if (tempItem == NULL)
            break;

        while (1)
        {
            if (tempItem == NULL)
                break;

            //cout << tempItem->freq << " > " << prevItem->freq << endl;

            if ((tempItem->freq > prevItem->freq))
            {

                tempFreq = tempItem->freq;
                tempData = tempItem->data;

                tempItem->data = prevItem->data;
                tempItem->freq = prevItem->freq;

                prevItem->freq = tempFreq;
                prevItem->data = tempData;
            }
            tempItem = tempItem->next;
        }
        if (prevItem->next == NULL)
            break;

        prevItem = prevItem->next;
        tempItem = prevItem;
    }

}

void generateFirstItemSet(char* LL_frequency)
{
    head->checkFrequency();
    int limit = noOfTransactions * supportThreshold;

    ofstream outFile(LL_frequency);

    //cout << "\nGenerating First Item Set\n";

    TransactionLL* tempTrans = head;
    Item* prevItemStore = NULL;

    //char* tempArray[25];
    int i = 0;

    while (1)
    {
        if (!tempTrans) // tempTrans == NULL
            break;

        Item* tempItems = tempTrans->items;
        if (tempItems == head->items && i != 0)
            break;

        while (1)
        {
            if (tempItems == NULL)
                break;

            if (tempItems->freq >= limit)
            {
                tempArray[i] = tempItems->data;
                i++;
            }
            else
            {
                head->deleteItem(tempItems->data);
                tempItems = prevItemStore;
            }

            if (tempItems == NULL)
                break;

            if (tempItems->next == NULL)
                break;

            prevItemStore = tempItems;
            tempItems = tempItems->next;
        }

        cout << endl;

        if (tempTrans->next == NULL)
            break;
        if (tempTrans->next != NULL)
            tempTrans = tempTrans->next;
    }

    removeCharDuplicates(tempArray, i);

    //sortList(tempArray, i);
    tempArraySize = i;
    tempTrans = head;
    int k = 0;

    TransactionLL* setOneLL = new TransactionLL;
    Item* setOneItem = setOneLL->items;

    Item* setOnePrev = NULL;

    while (1)
    {
        if (tempTrans == NULL)
            break;

        Item* tempItems;
        tempItems = tempTrans->items;

        while (1)
        {
            if (k == i)
                break;
            if (tempItems->data == tempArray[k])
            {
                //cout << tempItems->data << "(" << tempItems->freq << ")" << endl;

                setOneItem = new Item();
                setOneItem->data = tempItems->data;
                setOneItem->freq = tempItems->freq;
                setOneItem->next = NULL;

                if (setOnePrev != NULL)
                {
                    setOnePrev->next = setOneItem;
                }
                else


                    if (k == 0)
                        setOneLL->items = setOneItem;

                setOnePrev = setOneItem;

                //cout << setOneItem->next << endl;

                setOneItem = setOneItem->next;

                //outFile << tempItems->data << "(" << tempItems->freq << ")";
                //if (k + 1 != i) // to make sure there is no endl at the very end of the file
                    //outFile << endl;

                k++;
            }

            if (tempItems->next == NULL)
                break;

            tempItems = tempItems->next;
        }

        tempTrans = tempTrans->next;
    }

    sortSetOne(setOneLL);
    //printItems(setOneLL->items);

    Item* tempItem = setOneLL->items;
    k = 0;
    while (1)
    {
        if (tempItem == NULL)
            break;

        outFile << tempItem->data << "(" << tempItem->freq << ")";
        if (k + 1 != i) // to make sure there is no endl at the very end of the file
            outFile << endl;

        k++;
        tempItem = tempItem->next;
    }

    SetOneDone = 1;
}

void writingTransactionLLToFile(char* filePath)
{

    //cout << "writing file\n";
    ofstream outfile(filePath);

    TransactionLL* tempTrans = head;

    while (1)
    {
        if (tempTrans == NULL)
            break;

        Item* tempItems;
        tempItems = tempTrans->items;

        while (1)
        {
            //cout << tempItems->data << endl; // not showing any output here even tho the address of this is same as the one used before to store data
            outfile << tempItems->data;

            if (tempItems->next != NULL)
                outfile << ",";

            if (tempItems->next == NULL)
                break;

            tempItems = tempItems->next;
        }

        tempTrans = tempTrans->next;
        if (tempTrans != NULL)
            outfile << endl;
    }

}

void readInputFile(char* inputFilePath)
{
    head = NULL;
    SetOneDone = 0;
    //cout << "Reading file\n";
    ifstream infile;
    infile.open(inputFilePath);
    infile >> supportThreshold;
    infile >> noOfTransactions;

    if (head != NULL)
        head = NULL;

    char str[50];

    for (int i = 0; i < noOfTransactions; i++)
    {
        infile >> str;
        head->insertTrasaction(str);
    }

}

void removePunctuationMarks()
{
    head->formatData(0);
}

void convertUpperToLowerCase()
{
    head->formatData(1);
}

void printAll(TransactionLL* tempTrans)
{
    //TransactionLL* tempTrans = head;
    cout << endl;
    while (1)
    {
        if (tempTrans == NULL)
        {
            break;
        }

        Item* tempItems;
        tempItems = tempTrans->items;

        cout << tempItems->data << " ,";
        cout << tempItems->next->data << " " << tempItems->freq << endl;

        tempTrans = tempTrans->next;
    }
}

void secondFreqCheck(TransactionLL* headPtr)
{
    TransactionLL* tempTrans = headPtr;

    TransactionLL* realTrans;

    Item* realItem;
    Item* tempItem = tempTrans->items;

    int check = 0;

    while (1) // keep track of the 2set Items
    {
        if (tempTrans == NULL)
            break;

        realTrans = head;
        tempItem->freq = 0;

        while (1) // transaction check
        {
            if (realTrans == NULL)
                break;

            realItem = realTrans->items;

            while (1) // items check
            {
                if (realItem == NULL)
                    break;

                if (check == 2) // if two items match then its a full match
                {
                    tempItem->freq += 1;
                    check = 0;
                    break;
                }

                if (realItem->data[0] == tempItem->data[0] && realItem->data[1] == tempItem->data[1]) // if it finds a match in this transaction
                {
                    check++;
                    if (check == 2) // if two items match then its a full match
                    {
                        tempItem->freq += 1;
                        check = 0;
                        break;
                    }
                }
                else if (realItem->data[0] == tempItem->next->data[0] && realItem->data[1] == tempItem->next->data[1]) // if it finds a match in this transaction
                {
                    check++;
                    if (check == 2) // if two items match then its a full match
                    {
                        tempItem->freq += 1;
                        check = 0;
                        break;
                    }
                }
                realItem = realItem->next;
            }
            check = 0;
            realTrans = realTrans->next;
        }

        if (tempTrans->next == NULL)
            break;

        tempTrans = tempTrans->next;
        tempItem = tempTrans->items;
    }
}

void sortSetTwo(TransactionLL* headPtr)
{
    TransactionLL* tempTrans = headPtr;

    TransactionLL* prevTrans = NULL;
    char* tempData;
    char* tempDataNext;
    int tempFreq;

    while (1)
    {
        if (prevTrans == NULL) // starting point
        {
            prevTrans = tempTrans;
            tempTrans = tempTrans->next;
            continue;
        }

        if (tempTrans->next == NULL) // ending point
            break;

        while (1)
        {
            if (tempTrans == NULL)
                break;

            if (tempTrans->items->freq > prevTrans->items->freq)
            {
                tempFreq = tempTrans->items->freq;
                tempData = tempTrans->items->data;
                tempDataNext = tempTrans->items->next->data;

                tempTrans->items->data = prevTrans->items->data;
                tempTrans->items->freq = prevTrans->items->freq;
                tempTrans->items->next->data = prevTrans->items->next->data;

                prevTrans->items->freq = tempFreq;
                prevTrans->items->data = tempData;
                prevTrans->items->next->data = tempDataNext;

            }
            tempTrans = tempTrans->next;
        }
        prevTrans = prevTrans->next;
        tempTrans = prevTrans;
    }
}

/*void generateSecondItemSet(char* frequency_outputfile)
{
    if(SetOneDone == 0) // if set one is not generated before it will generate from here
        generateFirstItemSet("extra.txt"); // because if the second set is generated straight away it doesn't work properly

    TransactionLL* tempTrans = head;
    //TransactionLL* Itemset2Head = new TransactionLL; // this will now store the new data

    Item* itemSetTwoHead = NULL; // this will store the LL for itemset2
    Item* tempSet2 = NULL;

    TransactionLL* Set2 = NULL;

    Item* set2Item;// = Set2->items;

    TransactionLL* tempLL;

    while (1)
    {
        if (tempTrans == NULL)
            break;

        Item* tempItems;
        tempItems = tempTrans->items;
        bool checkCopy = 1;

        int i = 0;
        while (1)
        {
            if (i == tempArraySize)
                break;
            if (tempItems->data[0] == tempArray[i][0]) // data found, e.g. the first one is bread
            {
                for (int j = 0; j < tempArraySize; j++) // going through entire array to find all combinations
                {
                    if (i != j) // so same elements are not combined
                    {
                        Item* tempVar = new Item;
                        tempVar->data = charConcatinate(tempItems->data, tempArray[j]);
                        tempVar->next = NULL;

                        Item* tempChecker = itemSetTwoHead;

                        while (itemSetTwoHead != NULL) // to not add duplicates again this checks that
                        {
                            if (tempChecker->next == NULL)
                                break;

                            if (charArraySum(tempChecker->data) == charArraySum(tempVar->data))
                            {
                                checkCopy = 0;
                                break;
                            }
                            tempChecker = tempChecker->next;
                        }


                        if (tempSet2 != NULL && checkCopy) // when set is not empty
                        {

                            tempSet2->next = tempVar;
                            tempSet2 = tempSet2->next;
                        }
                        else if (tempSet2 == NULL && checkCopy) // when set is empty, for trans stuff put it here
                        {
                            tempSet2 = tempVar;
                            itemSetTwoHead = tempSet2;
                        }

                        if (Set2 == NULL && checkCopy)
                        {

                            tempLL = new TransactionLL;
                            Set2 = tempLL;
                            set2Item = new Item;
                            set2Item->data = tempItems->data; // first item
                            set2Item->next = new Item;
                            set2Item->next->data = tempArray[j]; // second item
                            set2Item->next->next = NULL; // line ended

                            tempLL->items = set2Item;
                            tempLL->next = NULL;
                        }
                        else if (checkCopy)
                        {
                            Item* tempItemSet = new Item();
                            tempItemSet->data = tempItems->data; // this is the worst thing ever
                            tempItemSet->next = new Item();
                            tempItemSet->next->data = tempArray[j];
                            tempItemSet->next->next = NULL;

                            TransactionLL* tempPtr = tempLL;

                            tempLL = new TransactionLL();
                            tempLL->items = tempItemSet;
                            tempLL->next = NULL;
                            tempPtr->next = tempLL;
                        }

                    }
                    checkCopy = 1;
                }
                i++;
            }
            if (tempItems->next == NULL)
                break;

            tempItems = tempItems->next;
        }

        tempTrans = tempTrans->next;
    }

    //cout << "SET2 Exception: " << Set2 << endl;

    secondFreqCheck(Set2);

    sortSetTwo(Set2);


    int limit = noOfTransactions * supportThreshold;

    ofstream outfile(frequency_outputfile);

    // generating file
    tempTrans = Set2;
    while (1)
    {
        if (tempTrans == NULL)
        {
            break;
        }

        Item* tempItems;
        tempItems = tempTrans->items;

        if (tempItems->freq >= limit)
        {
            cout << tempItems->data << " ,";
            cout << tempItems->next->data << " " << tempItems->freq << endl;
            outfile << tempItems->data << "," << tempItems->next->data << "(" << tempItems->freq << ")";
            if (tempTrans->next->items->freq >= limit)
                outfile << endl;
        }
        tempTrans = tempTrans->next;
    }

    outfile.close();

}*/

void generateSecondItemSet(char* frequency_outputfile)
{
    if (SetOneDone == 0) // if set one is not generated before it will generate from here
        generateFirstItemSet("extra.txt"); // because if the second set is generated straight away it doesn't work properly

    TransactionLL* tempTrans = head;
    //TransactionLL* Itemset2Head = new TransactionLL; // this will now store the new data

    Item* itemSetTwoHead = NULL; // this will store the LL for itemset2
    Item* tempSet2 = NULL;

    TransactionLL* Set2 = NULL;

    Item* set2Item;// = Set2->items;

    TransactionLL* tempLL;

    while (1)
    {
        if (tempTrans == NULL)
            break;

        Item* tempItems;
        tempItems = tempTrans->items;
        bool checkCopy = 1;

        int i = 0;
        while (1)
        {
            if (i == tempArraySize)
                break;
            if (tempItems->data[0] == tempArray[i][0]) // data found, e.g. the first one is bread
            {
                for (int j = 0; j < tempArraySize; j++) // going through entire array to find all combinations
                {
                    if (i != j) // so same elements are not combined
                    {
                        Item* tempVar = new Item;
                        tempVar->data = charConcatinate(tempItems->data, tempArray[j]);
                        tempVar->next = NULL;

                        Item* tempChecker = itemSetTwoHead;

                        while (itemSetTwoHead != NULL) // to not add duplicates again this checks that
                        {
                            if (tempChecker->next == NULL)
                                break;

                            if (charArraySum(tempChecker->data) == charArraySum(tempVar->data))
                            {
                                checkCopy = 0;
                                break;
                            }
                            tempChecker = tempChecker->next;
                        }


                        if (tempSet2 != NULL && checkCopy) // when set is not empty
                        {

                            tempSet2->next = tempVar;
                            tempSet2 = tempSet2->next;
                        }
                        else if (tempSet2 == NULL && checkCopy) // when set is empty, for trans stuff put it here
                        {
                            tempSet2 = tempVar;
                            itemSetTwoHead = tempSet2;
                        }


                        if (Set2 == NULL && checkCopy)
                        {

                            tempLL = new TransactionLL;
                            Set2 = tempLL;
                            set2Item = new Item;
                            set2Item->data = tempItems->data; // first item
                            set2Item->next = new Item;
                            set2Item->next->data = tempArray[j]; // second item
                            set2Item->next->next = NULL; // line ended

                            tempLL->items = set2Item;
                            tempLL->next = NULL;
                        }
                        else if (checkCopy)
                        {
                            Item* tempItemSet = new Item;
                            tempItemSet->data = tempItems->data; // this is the worst thing ever
                            tempItemSet->next = new Item;
                            tempItemSet->next->data = tempArray[j];
                            tempItemSet->next->next = NULL;

                            TransactionLL* tempPtr = tempLL;

                            tempLL = new TransactionLL;
                            tempLL->items = tempItemSet;
                            tempLL->next = NULL;
                            tempPtr->next = tempLL;
                        }

                    }
                    checkCopy = 1;
                }
                i++;
            }
            if (tempItems->next == NULL)
                break;

            tempItems = tempItems->next;
        }

        tempTrans = tempTrans->next;
    }

    secondFreqCheck(Set2);

    sortSetTwo(Set2);


    int limit = noOfTransactions * supportThreshold;

    ofstream outfile(frequency_outputfile);

    // generating file
    tempTrans = Set2;
    while (1)
    {
        if (tempTrans == NULL)
        {
            break;
        }

        Item* tempItems;
        tempItems = tempTrans->items;

        if (tempItems->freq >= limit)
        {
            //cout << tempItems->data << " ,";
            //cout << tempItems->next->data << " " << tempItems->freq << endl;
            outfile << tempItems->data << "," << tempItems->next->data << "(" << tempItems->freq << ")";
            if (tempTrans->next->items->freq >= limit)
                outfile << endl;
        }
        tempTrans = tempTrans->next;
    }

    outfile.close();

}

void generateThirdItemSet(char* frequency_outputfile)
{
}
