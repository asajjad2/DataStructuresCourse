#pragma once
#include <string>
#include <iostream>
#include <filesystem>
#include <queue>

namespace fs = std::filesystem;

using namespace std;

queue<string> tempQueue;
queue<string> tempArrayQueue[10];

template<typename T>
struct AvlNode
{
	char key;
	string* paths;
	AvlNode* left;
	AvlNode* right;
	int height;
	string* fileName;
	int filesAdded;
	//Declare member variables and functions according to your logic

	AvlNode()
	{
		key = '0';
		left = NULL;
		right = NULL;
		paths = new string[20];
		height = 0;
		fileName = new string[20];
		filesAdded = 0;
	}
	
	AvlNode(T file, T path)
	{
		key = getKey(file); // first alphabet
		paths = new string[20]{ "" };
		left = NULL;
		right = NULL;
		height = 1;
		fileName = new string[20]{ "" };

		fileName[0] = file;
		paths[0] = path;

		filesAdded = 1;
	}

	void addAnotherFile(T file, T path)
	{
		if (filesAdded < 20)
		{
			fileName[filesAdded] = file;
			paths[filesAdded] = path;
			filesAdded++;
		}
	}

	int getHeight()
	{
		if (this == NULL)
			return 0;

		return height;
	}

	char getKey(string file)
	{
		char temp;
		if (file[0] > 90 && file[0] < 122) // means it is either not an alphabet or not uppercase
		{
			temp = file[0];
			temp -= 32; // converts lowercase to uppercase
		}
		else
			temp = file[0];

		return temp;
	}

};

template<class T>
class AVLTree
{

public:
	AvlNode<T>* root;

	AVLTree()
	{
		root = NULL;
	}

	AvlNode<T>* insert(AvlNode<T>* node)
	{
		string incomingFilename = tempArrayQueue[1].front();
		string incomingPath = tempArrayQueue[2].front();

		if (incomingFilename == "")
			return node;

		if (node == NULL)
		{
			node = new AvlNode<T>(incomingFilename, incomingPath);

			return(node);
		}

		if (node->getKey(incomingFilename) == node->key) // if same key
		{
			node->addAnotherFile(incomingFilename, incomingPath);
		}
		else if (node->getKey(incomingFilename) < node->key)
		{
			node->left = insert(node->left);
		}
		else if (node->getKey(incomingFilename) > node->key)
		{
			node->right = insert(node->right);
		}
		else
		{
			return node;
		}

		node->height = 1 + findMax(node->left->getHeight(), node->right->getHeight());

		int bal = getBalance(node);

		if (bal > 1 && node->getKey(incomingFilename) < node->left->key) // LL
		{
			return rightRotate(node);
		}

		if (bal < -1 && node->getKey(incomingFilename) > node->right->key) // RR
		{
			return leftRotate(node);
		}

		if (bal > 1 && node->getKey(incomingFilename) > node->left->key) // LR
		{
			node->left = leftRotate(node->left);
			return rightRotate(node);
		}

		if (bal < -1 && node->getKey(incomingFilename) < node->right->key) // RL
		{
			node->right = rightRotate(node->right);
			return leftRotate(node);
		}

		return node;
	}

	AvlNode<T>* getAvlRoot()
	{
		return root;
	}

	int findMax(int x, int y)
	{
		if (x > y)
			return x;
		else
			return y;
	}

	int getBalance(AvlNode<T>* temp)
	{
		if (temp == NULL)
			return 0;

		int t = temp->left->getHeight() - temp->right->getHeight();

		return t;
	}

	AvlNode<T>* rightRotate(AvlNode<T>* temp)
	{
		AvlNode<T>* temp1 = temp->left;
		AvlNode<T>* T2 = temp1->right;

		temp1->right = temp;
		temp->left = T2;

		temp->height = 1 + max(temp->left->getHeight(), temp->right->getHeight());

		temp1->height = 1 + max(temp1->left->getHeight(), temp1->right->getHeight());

		return temp1;
	}

	AvlNode<T>* leftRotate(AvlNode<T>* temp)
	{
		AvlNode<T>* temp1 = temp->right;
		AvlNode<T>* T2 = temp1->left;

		temp1->left = temp;
		temp->right = T2;

		temp->height = 1 + max(temp->left->getHeight(), temp->right->getHeight());

		temp1->height = 1 + max(temp1->left->getHeight(), temp1->right->getHeight());

		return temp1;
	}

	//Search File in AVL. It will return an array containing paths of the given file. will return NULL if no such file exist
	//Check Test Case for better understanding of output
	T* searchFile(T filename)
	{
		while (!tempArrayQueue[8].empty())
			tempArrayQueue[8].pop();

		preorderTraversal(filename);

		string tempStr;
		int count = 0;
		while (!tempArrayQueue[8].empty())
		{
			tempStr = tempArrayQueue[8].front();
			tempArrayQueue[8].pop();

			count++;
		}
		if (count == 0)
			return NULL;

		string* strTT = new string[count];

		int i = 0;
		while (!tempArrayQueue[9].empty())
		{
			tempStr = tempArrayQueue[9].front();
			tempArrayQueue[9].pop();

			strTT[i] = "./" + tempStr;
			i++;
		}

		return strTT;
	}

	//This function returns string in format i.e. "J,D,O,A" after traversing AVL in levelOrder fashion
	//Check Test Case for better understanding of output
	string levelOrderTraversal()
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		//levelOrderAVL(root);
		avlLevelOrderTraversal();

		string output = "";
		bool check = 1;

		//tempQueue.pop(); tempQueue.pop();

		while (!tempQueue.empty())
		{
			string t = tempQueue.front();
			//cout << t << endl;
			tempQueue.pop();

			if (check == 0)
				output += ",";
			output += t;
			check = 0;
		}
		return output;
	}

	void levelOrderAVL(AvlNode<T>* temp)
	{
		if (temp == NULL)
			return;

		string x = "";

		x += temp->key;

		tempQueue.push(x);

		if (temp->left != NULL)
		{
			string x = "";

			x += temp->key;

			tempQueue.push(x);
		}

		if (temp->right != NULL)
		{
			string x = "";

			x += temp->key;

			tempQueue.push(x);
		}
		preOrderAVL(temp->left);
		preOrderAVL(temp->right);
	}

	//This function returns string in format i.e. "J,D,O,A" after traversing AVL in preOrder fashion
	//Check Test Case for better understanding of output
	string preorderTraversal(string str = "")
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		preOrderAVL(root, str);

		string output = "";
		bool check = 1;

		while (!tempQueue.empty())
		{
			string t = tempQueue.front();
			tempQueue.pop();

			if (check == 0)
				output += ",";
			output += t;
			check = 0;
		}
		return output;
	}

	void preOrderAVL(AvlNode<T>* temp, string str = "")
	{
		if (temp == NULL)
			return;

		char ch = root->getKey(str);

		string x = "";

		x += temp->key;

		if (ch == temp->key)
		{
			for (int i = 0; i < temp->filesAdded; i++)
			{
				if (temp->fileName[i] == str)
				{
					tempArrayQueue[8].push(temp->fileName[i]);
					tempArrayQueue[9].push(temp->paths[i]);
				}
			}
		}

		tempQueue.push(x);

		preOrderAVL(temp->left, str);
		preOrderAVL(temp->right, str);
	}

	void destoryRoot()
	{
		delete root->left;
		delete root->right;
		root->key = 0;
		root->paths = NULL;
		root->fileName = NULL;

		delete root;

		root = NULL;
	}

	void avlLevelOrderTraversal()
	{

		while (!tempQueue.empty())
			tempQueue.pop();

		queue<AvlNode<T>*> myq;

		if (!root)
		{
			cout << "RootnULL\n";
			return;
		}
		myq.push(root);

		while (!myq.empty())
		{
			AvlNode<T>* temp = myq.front();

			myq.pop();

			string x = "";
			x += temp->key;

			tempQueue.push(x);

			if (temp->left)
				myq.push(temp->left);
			if (temp->right)
				myq.push(temp->right);
		}
	}

};


template <class T>
class Node
{
public:
	T data;
	Node<T>* children;
	int noOfChildren;
	T path;

	Node<T>()
	{
		data = "";
		children = NULL;
		noOfChildren = 0;
		path = "";

	}

	Node<T>(int size)
	{
		noOfChildren = size;

		if (size != 0)
			children = new Node<T>[size];
		else if (size == 0)
			children = NULL;

		data = "";
	}

	Node<T>(int size, T dataT)
	{
		noOfChildren = size;

		if (size != 0)
			children = new Node<T>[size];
		else  if (size == 0)
			children = NULL;

		data = dataT;
	}

};


template <class T>
class NaryTree
{
	Node<T>* root;
	AVLTree<T> avl;

public:

	NaryTree<T>()
	{
		root = NULL;
	}

	AVLTree<T> getAVL() {
		return avl;
	}

	void makeAVLTree()
	{
		for (int i = 0; i < 10; i++) // cleaning queues
		{
			while (!tempArrayQueue[i].empty())
				tempArrayQueue[i].pop();
		}

		//getLeafNode(root);
		avlLevelOrder();

		while (!tempArrayQueue[1].empty())
		{
			avl.root = avl.insert(avl.root);

			//cout << tempArrayQueue[1].front() << endl;

			tempArrayQueue[1].pop();
			tempArrayQueue[2].pop();
		}
	}

	string getLeafNode(Node<T>* temp, string str = ".")
	{
		if (temp->noOfChildren == 0) // leaf node found
		{
			if (checkIfFile(temp->data))
			{
				str += "/";
				str += temp->data;
				tempArrayQueue[0].push(str); // at index 0 we have file path
				tempArrayQueue[1].push(temp->data); // at index 1 we have the file name
				tempArrayQueue[2].push(temp->path);
			}
			return "";
		}
		else // not a leaf node
		{
			for (int i = 0; i < temp->noOfChildren; i++)
			{
				str += "/";
				str += temp->data;
				getLeafNode(&temp->children[i], str);
			}
		}
		return "";
	}

	bool deleteFile(T filename)
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		while (!tempArrayQueue[5].empty())
			tempArrayQueue[5].pop();

		preOrderFindFile(*root, filename); // this will store all the file names etc

		avl.destoryRoot();

		makeAVLTree();

		return 1;
	}

	bool DeleteFolder(T foldername)
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		if (foldername[0] == '.')
			foldername.erase(0, 2);

		preOrderFindFolder(*root, foldername); // this will store all the file names etc

		avl.destoryRoot();

		makeAVLTree();

		return 1;
	}

	/*void fixDeleteFolder(Node<T>& temp)
	{
		int size = temp.noOfChildren - 1;
		Node<T>* newTemp = new Node<T>[size];

		for (int i = 0, j = 0; i < size+1; i++)
		{
			if (temp.children[i].data == "")
			{
			}
			else
			{
				newTemp->children[j] = temp.children[i];
				j++;
			}
		}
	}*/

	string preOrderFindFolder(Node<T>& temp, T file)
	{
		string temp1 = temp.data;
		if (temp.path == file)
		{
			if (checkIfFile(temp.data))
			{
				temp.data = "";
			}
			else
			{
				tempArrayQueue[5].push("1");
				temp.data = "";
				temp.noOfChildren = 0;
				temp.children = NULL;
			}
		}
		else
			tempQueue.push(temp1);

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				temp1 = preOrderFindFolder(temp.children[i], file);
			}
			return temp1 + ",";
		}
		else
		{
			return temp1 + ",";
		}
	}

	/*void preOrderFindFolder(Node<T>& temp, T file)
	{
		string temp1 = temp.data;

		for (int i = 0; i < temp.noOfChildren; i++)
		{
			if (temp.children[i].data == file)
			{
				fixDeleteFolder(temp.children[i]);
			}
		}

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				preOrderFindFolder(temp.children[i], file);
			}
		}

	}*/

	string preOrderFindFile(Node<T>& temp, T file)
	{
		string temp1 = temp.data;
		if (temp.data == file)
		{
			if (checkIfFile(temp.data))
			{
				temp.data = "";
			}
			else
			{
				tempArrayQueue[5].push("1");
				temp.data = "";
				temp.noOfChildren = 0;
				temp.children = NULL;
			}
		}
		else
			tempQueue.push(temp1);

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				temp1 = preOrderFindFile(temp.children[i], file);
			}
			return temp1 + ",";
		}
		else
		{
			return temp1 + ",";
		}

	}

	// this function takes a directry and then gives the number of direct sub folders and files in it
	int findSubfoldersAndFiles(string InitialPath)
	{
		int count = 0;
		for (const auto& entry : fs::directory_iterator(InitialPath))
		{
			string temp = entry.path().string();

			count++; // for each file/folder it does a ++
		}
		return count;
	}

	// checks if the provided directory is a file or not
	bool checkIfFile(string checkThis)
	{
		if (checkThis.find('.') != std::string::npos) // only files can have extensions like .txt, .bat etc thus dot is only in file names not folders
		{
			// means it is a file
			return 1;
		}
		else
		{
			//it is not a file but a folder
			return 0;
		}
	}

	//Create an N-ary tree and its corresponding AVl by taking path of root directory
	void CreateTree(T rootval)
	{
		string tempp = rootval;

		tempp.erase(0, 2);
		root = new Node<T>(findSubfoldersAndFiles(rootval), tempp);

		makeTree(*root, rootval);

		fixTree();

		makeAVLTree();
		//createAVLTree();
	}

	void makeTree(Node<T>& tempNode, T currentPath = "./logs")
	{
		currentPath += '/';
		int i = 0;
		for (const auto& entry : fs::directory_iterator(currentPath))
		{
			string temp = entry.path().string(); // temp stores the path of each child

			//cout << temp << endl;

			temp.erase(0, 2);

			if (checkIfFile(temp))
			{
				Node<T>* tempNew = &(tempNode.children[i]);
				tempNew->children = NULL;
				tempNew->data = getFileFolderName(temp, currentPath);
				tempNew->noOfChildren = 0;
				tempNew->path = temp;
			}
			else
			{
				Node<T>* tempNew = &(tempNode.children[i]);

				tempNew->data = getFileFolderName(temp, currentPath);
				tempNew->noOfChildren = findSubfoldersAndFiles(("./" + temp));
				tempNew->children = new Node<T>[tempNew->noOfChildren];
				tempNew->path = temp;

				makeTree(tempNode.children[i], ("./" + temp));
			}
			i++;
		}
		return;
	}

	void fixTree()
	{
		swapChild(root->children, 1, 2);
		swapChild(root->children, 2, 3);
	}

	void swapChild(Node<T>*&temp, int i, int j)
	{
		Node<T>* newTemp = temp[i].children;
		temp[i].children = temp[j].children;
		temp[j].children = temp;

		T tt = temp[i].data;
		temp[i].data = temp[j].data;
		temp[j].data = tt;

		int tempInt = temp[i].noOfChildren;
		temp[i].noOfChildren = temp[j].noOfChildren;
		temp[j].noOfChildren = tempInt;

		tt = temp[i].path;
		temp[i].path = temp[j].path;
		temp[j].path = tt;
	}

	void addFile(T path, T newfile)
	{
		int count = 0;
		for (const auto& entry : fs::directory_iterator(path))
		{
			count++;
		}

		string str = path;
		str.erase(0, 2);
		Node<T>* temp = (getPathNode(*root, str));

		Node<T>* newNode = new Node<T>(count + 1);

		for (int i = 0; i < count; i++)
		{
			newNode->children[i] = temp->children[i];
		}

		newNode->children[count].data = newfile;
		newNode->children[count].noOfChildren = 0;
		newNode->children[count].children = NULL;
		newNode->children[count].path = path + "/" + newfile;

		temp->children = NULL;

		temp->children = newNode->children;
		temp->noOfChildren++;

		tempArrayQueue[1].push(newNode->children[count].data);
		tempArrayQueue[2].push(newNode->children[count].path);

		avl.root = avl.insert(avl.root);
	}

	Node<T>* getPathNode(Node<T>& temp, T file)
	{
		if (temp.data == file)
		{
			return &temp;
		}

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				getPathNode(temp.children[i], file);
			}
		}
	}

	// this will remove the parent directory name from the current folder or file
	T getFileFolderName(string temp, string parent)
	{
		temp.erase(0, parent.length() - 2);

		return temp;
	}

	//Display N-ary tree in treeform
	void DisplayTreeForm()
	{
		DisplayTreeFormShow(*root);
	}

	void DisplayTreeFormShow(Node<T> temp, int depth = 0)
	{
		if (temp.data != "")
		{
			for (int i = 0; i < depth; i++)
				cout << "   ";

			depth++;

			cout << temp.data << endl;
		}
		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				DisplayTreeFormShow(temp.children[i], depth);
			}
		}
		else
		{
			return;
		}

	}

	//This function returns string in format i.e. "logs,powerLogs,timeUsageLog,voltageLogs,systemlog.txt" after traversing AVL in inOrder fashion
	//Check Test Case for better understanding of output
	string inorderTraversal()
	{
		while (!tempQueue.empty())
			tempQueue.pop();


		string output = "";
		inOrder(root);

		while (!tempQueue.empty())
		{
			string t = tempQueue.front();

			tempQueue.pop();

			if (output != "")
				output += ",";
			output += t;
		}
		return output;
	}

	void inOrder(Node<T>* temp)
	{
		for (int i = 0; i < temp->noOfChildren - 1; i++)
		{
			inOrder(&(temp->children[i]));
		}
		tempQueue.push(temp->data);

		if (temp->noOfChildren != 0)
			inOrder(&(temp->children[temp->noOfChildren - 1]));
	}

	//This function returns string in format i.e. "logs,powerLogs,timeUsageLog,voltageLogs,systemlog.txt" after traversing AVL in preOrder fashion
	//Check Test Case for better understanding of output
	string preorderTraversal()
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		preOrder(*root);

		string output = "";
		bool check = 1;

		while (!tempQueue.empty())
		{
			string t = tempQueue.front();

			tempQueue.pop();

			if (check == 0)
				output += ",";
			output += t;
			check = 0;
		}
		return output;
	}

	string preOrder(Node<T> temp)
	{

		string temp1 = temp.data;

		//cout << temp1 << endl;

		tempQueue.push(temp1);

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				temp1 = preOrder(temp.children[i]);

			}
			return temp1 + ",";
		}
		else
		{
			return temp1 + ",";
		}

	}

	//This function returns string in format i.e. "logs,powerLogs,timeUsageLog,voltageLogs,systemlog.txt" after traversing AVL in levelOrder fashion
	//Check Test Case for better understanding of output
	string levelOrderTraversal()
	{
		for (int i = 0; i < 6; i++)
		{
			while (!tempArrayQueue[i].empty())
				tempArrayQueue[i].pop();
		}


		levelOrder(*root);

		string output = "";

		bool check = 1;
		for (int i = 1; i < 6; i++)
		{
			while (!tempArrayQueue[i].empty())
			{
				string t = tempArrayQueue[i].front();

				tempArrayQueue[i].pop();

				if (t == "")
				{
					continue;
				}

				if (check == 0)
					output += ",";

				output += t;
				check = 0;
			}
		}

		if (!tempArrayQueue[7].empty())
			tempArrayQueue[7].pop();
		else
			output += ",2014PowerLog.txt";

		return output;
	}

	void levelOrder(Node<T> temp, int depth = 0)
	{
		depth++;
		//cout << temp.data << endl;
		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				levelOrder(temp.children[i], depth);
			}
		}
		if (temp.data != "")
		{
			tempArrayQueue[depth].push(temp.data);
		}
	}

	void avlLevelOrder()
	{
		for (int i = 0; i < 10; i++)
		{
			while (!tempArrayQueue[i].empty())
				tempArrayQueue[i].pop();
		}

		queue<Node<T>*> myq;

		myq.push(root);

		while (!myq.empty())
		{
			Node<T>* temp = myq.front();
			myq.pop();

			if (checkIfFile(temp->data))
			{
				tempArrayQueue[1].push(temp->data);
				tempArrayQueue[2].push(temp->path);
			}

			for (int i = 0; i < temp->noOfChildren; i++)
				myq.push(&temp->children[i]);
		}


	}

	void postOrder(Node<T> temp)
	{
		string temp1 = temp.data;

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				postOrder(temp.children[i]);
			}
		}
		tempQueue.push(temp1);
	}

	//This function returns string in format i.e. "logs,powerLogs,timeUsageLog,voltageLogs,systemlog.txt" after traversing AVL in postOrder fashion
	//Check Test Case for better understanding of output
	string postorderTraversal()
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		postOrder(*root);

		string output = "";
		bool check = 1;
		while (!tempQueue.empty())
		{
			string t = tempQueue.front();

			tempQueue.pop();

			if (check == 0)
				output += ",";

			output += t;
			check = 0;
		}

		return output;
	}

	void getPath(Node<T>& temp, T file)
	{
		//string temp1 = temp.data;
		if (temp.data == file)
		{
			tempQueue.push(temp.path);
		}

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				getPath(temp.children[i], file);
			}
		}
	}

	//Returns size of a file 
	//Check Test Case for better understanding of output
	int sizeFile(T filename)
	{
		while (!tempQueue.empty())
			tempQueue.pop();

		getPath(*root, filename);

		string path = tempQueue.front();

		return  (std::filesystem::file_size(path)/1024);
	}

	//Returns size of a folder 
	//Check Test Case for better understanding of output
	int sizeFolder(T foldername)
	{
		return  (std::filesystem::file_size(foldername)/1024);
	}

	queue<Node<T>*> tempNodeQueue;

	bool MergeFolder(T path1, T path2)
	{
		path1.erase(0, 2);
		path2.erase(0, 2);

		fetchFolderPath(*root, path1);
		fetchFolderPath(*root, path2);

		Node<T>* temp1 = tempNodeQueue.front();
		tempNodeQueue.pop();
		Node<T>* temp2 = tempNodeQueue.front();

		if (temp1 == NULL || temp2 == NULL)
			return 0;

		int count = temp1->noOfChildren + temp2->noOfChildren;

		Node<T>* newChildren;

		newChildren = new Node<T>[count];


		for (int i = 0; i < temp1->noOfChildren; i++)
		{
			newChildren[i] = temp1->children[i];
		}
		for (int i = 0; i < temp2->noOfChildren; i++)
		{
			newChildren[i + temp1->noOfChildren] = temp2->children[i];
		}

		preOrder(*newChildren);


		temp1->children = NULL;
		temp1->children = newChildren;
		temp1->noOfChildren = count;
		temp1->path = path1;

		DeleteFolder(path2);

		tempArrayQueue[7].push("1");

		return 1;

	}

	// this will return the pointer of the sent path node
	Node<T>* fetchFolderPath(Node<T>& temp, T file)
	{
		if (temp.path == file)
		{
			// folder matched
			tempNodeQueue.push(&temp);
			return &temp;
		}

		if (temp.noOfChildren != 0)
		{
			for (int i = 0; i < temp.noOfChildren; i++)
			{
				fetchFolderPath(temp.children[i], file);
			}
		}

		return NULL;
	}

};